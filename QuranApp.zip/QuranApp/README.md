# تطبيق القرآن الكريم
Kotlin + Jetpack Compose. النص والصوت من واجهة Al Quran Cloud المجانية (قارئ: مشاري العفاسي).
تغيير القارئ: QuranViewModel.kt (ar.alafasy). تغيير الاسم الفريد للتطبيق: app/build.gradle.kts (applicationId).
