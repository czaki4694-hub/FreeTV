@file:OptIn(ExperimentalMaterial3Api::class)

package io.github.czaki4694.quran

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(vm: QuranViewModel) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp)
    ) {
        Text("القرآن الكريم", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 16.dp, bottom = 8.dp))
        OutlinedTextField(
            value = vm.query, onValueChange = { vm.query = it },
            placeholder = { Text("ابحث عن سورة") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true, shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
        )
        val last = vm.surahs.firstOrNull { it.number == vm.lastSurah }
        if (last != null && vm.query.isBlank()) {
            Card(
                onClick = { vm.openSurah(last) }, shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)),
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("متابعة القراءة", style = MaterialTheme.typography.labelMedium)
                    Text("${last.name} • آية ${ar(vm.lastAyah)}", fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        when {
            vm.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            vm.error != null -> Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
                Text(vm.error ?: "", textAlign = TextAlign.Center)
                Button(onClick = vm::loadSurahs, modifier = Modifier.padding(top = 12.dp)) { Text("إعادة المحاولة") }
            }
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(vm.filtered, key = { it.number }) { s -> SurahRow(s) { vm.openSurah(s) } }
            }
        }
    }
}

@Composable
private fun SurahRow(s: SurahInfo, onClick: () -> Unit) {
    Card(onClick = onClick, shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center) {
                Text(ar(s.number), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.padding(start = 14.dp)) {
                Text(s.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
                Text("${if (s.meccan) "مكية" else "مدنية"} • ${ar(s.ayahs)} آية",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            }
        }
    }
}

@Composable
fun ReaderScreen(vm: QuranViewModel, s: SurahInfo) {
    BackHandler(onBack = vm::close)
    val listState = rememberLazyListState()
    LaunchedEffect(vm.ayahs) {
        if (vm.ayahs.isNotEmpty() && vm.lastSurah == s.number && vm.lastAyah > 1) {
            val idx = vm.ayahs.indexOfFirst { it.n == vm.lastAyah }
            if (idx >= 0) listState.scrollToItem(idx + 1)
        }
    }
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = vm::close) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") }
            Text(s.name, Modifier.weight(1f), fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            TextButton(onClick = { vm.setFont(vm.fontSize - 2) }) { Text("أ-") }
            TextButton(onClick = { vm.setFont(vm.fontSize + 2) }) { Text("أ+") }
            FilledTonalButton(onClick = { vm.toggleAudio(s) }) {
                Text(if (vm.playing && vm.audioSurah == s.number) "إيقاف" else "استماع")
            }
        }
        when {
            vm.readerLoading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            vm.readerError != null -> Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
                Text(vm.readerError ?: "")
                Button(onClick = { vm.openSurah(s) }, modifier = Modifier.padding(top = 12.dp)) { Text("إعادة المحاولة") }
            }
            else -> LazyColumn(state = listState, contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
                item {
                    vm.basmala?.let {
                        Text(it, fontSize = (vm.fontSize + 2).sp, textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp))
                    }
                }
                items(vm.ayahs, key = { it.n }) { a ->
                    val marked = vm.lastSurah == s.number && vm.lastAyah == a.n
                    Text(
                        "${a.text} \uFD3F${ar(a.n)}\uFD3E",
                        fontSize = vm.fontSize.sp, lineHeight = (vm.fontSize * 1.9f).sp,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .background(if (marked) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f) else Color.Transparent)
                            .clickable { vm.bookmark(s.number, a.n) }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}
