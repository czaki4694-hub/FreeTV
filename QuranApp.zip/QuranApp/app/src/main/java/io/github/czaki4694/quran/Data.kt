package io.github.czaki4694.quran

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class SurahInfo(val number: Int, val name: String, val english: String, val ayahs: Int, val meccan: Boolean)
data class Ayah(val n: Int, val text: String)

/** يجلب النص من واجهة Al Quran Cloud المجانية ويحفظه على الجهاز للقراءة دون إنترنت. */
class QuranRepo(private val ctx: Context) {
    private fun fetch(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun cached(name: String, url: String): JSONObject {
        val f = File(ctx.filesDir, name)
        if (f.exists()) return JSONObject(f.readText())
        val text = fetch(url)
        val json = JSONObject(text)
        if (json.optInt("code") == 200) f.writeText(text) else throw IllegalStateException("bad response")
        return json
    }

    suspend fun surahs(): List<SurahInfo> = withContext(Dispatchers.IO) {
        val d = cached("surahs.json", "https://api.alquran.cloud/v1/surah").getJSONArray("data")
        List(d.length()) {
            val o = d.getJSONObject(it)
            SurahInfo(o.getInt("number"), o.getString("name"), o.getString("englishName"),
                o.getInt("numberOfAyahs"), o.getString("revelationType") == "Meccan")
        }
    }

    suspend fun ayahs(n: Int): List<Ayah> = withContext(Dispatchers.IO) {
        val d = cached("surah_$n.json", "https://api.alquran.cloud/v1/surah/$n/quran-uthmani")
            .getJSONObject("data").getJSONArray("ayahs")
        List(d.length()) {
            val o = d.getJSONObject(it)
            Ayah(o.getInt("numberInSurah"), o.getString("text"))
        }
    }
}

fun ar(n: Int): String = n.toString().map { '٠' + (it - '0') }.joinToString("")

fun norm(s: String): String = s
    .filterNot { it.code in 0x064B..0x065F || it.code == 0x0670 || it.code in 0x06D6..0x06ED || it.code == 0x0640 }
    .replace('ٱ', 'ا').replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
