package io.github.czaki4694.quran

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Colors = darkColorScheme(
    primary = Color(0xFF4CC9A0),
    onPrimary = Color(0xFF00281C),
    background = Color(0xFF0B1210),
    surface = Color(0xFF131E1A),
    surfaceVariant = Color(0xFF1B2A24),
    onBackground = Color(0xFFE9EFEA),
    onSurface = Color(0xFFE9EFEA)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = Colors, content = content)
