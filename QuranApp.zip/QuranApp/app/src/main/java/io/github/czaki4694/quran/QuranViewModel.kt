package io.github.czaki4694.quran

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.launch

class QuranViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = QuranRepo(app)
    private val prefs = app.getSharedPreferences("quran", 0)

    var surahs by mutableStateOf(listOf<SurahInfo>()); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var query by mutableStateOf("")

    var open by mutableStateOf<SurahInfo?>(null); private set
    var ayahs by mutableStateOf(listOf<Ayah>()); private set
    var basmala by mutableStateOf<String?>(null); private set
    var readerLoading by mutableStateOf(false); private set
    var readerError by mutableStateOf<String?>(null); private set

    var fontSize by mutableStateOf(prefs.getInt("font", 28)); private set
    var lastSurah by mutableStateOf(prefs.getInt("lastSurah", 0)); private set
    var lastAyah by mutableStateOf(prefs.getInt("lastAyah", 0)); private set

    private val player = ExoPlayer.Builder(app).build()
    var playing by mutableStateOf(false); private set
    var audioSurah by mutableStateOf(0); private set

    val filtered: List<SurahInfo>
        get() {
            val q = norm(query.trim())
            return if (q.isEmpty()) surahs else surahs.filter {
                norm(it.name).contains(q) || it.english.contains(q, true) || it.number.toString() == q
            }
        }

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
        })
        loadSurahs()
    }

    fun loadSurahs() {
        viewModelScope.launch {
            loading = true; error = null
            try { surahs = repo.surahs() } catch (e: Exception) { error = "تعذّر التحميل، تحقق من الاتصال بالإنترنت" }
            loading = false
        }
    }

    fun openSurah(s: SurahInfo) {
        open = s; ayahs = emptyList(); basmala = null; readerError = null; readerLoading = true
        viewModelScope.launch {
            try {
                val list = repo.ayahs(s.number)
                val first = list.firstOrNull()
                if (s.number != 1 && s.number != 9 && first != null) {
                    val w = first.text.split(" ")
                    if (w.size > 4) {
                        basmala = w.take(4).joinToString(" ")
                        ayahs = listOf(Ayah(1, w.drop(4).joinToString(" "))) + list.drop(1)
                    } else ayahs = list
                } else ayahs = list
            } catch (e: Exception) { readerError = "تعذّر تحميل السورة، تحقق من الإنترنت" }
            readerLoading = false
        }
    }

    fun close() { open = null }

    fun setFont(v: Int) {
        fontSize = v.coerceIn(18, 48)
        prefs.edit().putInt("font", fontSize).apply()
    }

    fun bookmark(surah: Int, ayah: Int) {
        lastSurah = surah; lastAyah = ayah
        prefs.edit().putInt("lastSurah", surah).putInt("lastAyah", ayah).apply()
    }

    fun toggleAudio(s: SurahInfo) {
        if (audioSurah == s.number && player.mediaItemCount > 0) {
            if (player.isPlaying) player.pause() else player.play()
        } else {
            audioSurah = s.number
            player.setMediaItem(MediaItem.fromUri(
                "https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/${s.number}.mp3"))
            player.prepare(); player.play()
        }
    }

    override fun onCleared() { player.release() }
}
