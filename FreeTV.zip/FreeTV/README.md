# Free TV
مشغّل قنوات مجانية (HLS/M3U) بـ Kotlin + Jetpack Compose + Media3.
1. افتح المجلد في Android Studio (Koala أو أحدث) وانتظر مزامنة Gradle.
2. شغّل التطبيق. من ⚙ أضف رابط M3U لقنوات مجانية قانونية.
تعديل القنوات الافتراضية: Channel.kt — الألوان: Theme.kt — الواجهة: HomeScreen.kt

## بناء APK سحابياً
ارفع المشروع (مع مجلد .github) إلى GitHub، ثم من تبويب Actions نزّل FreeTV-apk.
