package com.example.freetv

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { Root() } }
    }
}

@Composable
fun Root(vm: MainViewModel = viewModel()) {
    val ctx = LocalContext.current
    // فتح المشغّل في شاشة (Activity) منفصلة
    LaunchedEffect(vm.current) {
        vm.current?.let {
            ctx.startActivity(
                Intent(ctx, PlayerActivity::class.java)
                    .putExtra("name", it.name).putExtra("url", it.url)
            )
            vm.current = null
        }
    }
    HomeScreen(vm)
}
