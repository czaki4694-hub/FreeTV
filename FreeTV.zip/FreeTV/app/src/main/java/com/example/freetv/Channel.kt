package com.example.freetv

data class Channel(
    val name: String,
    val url: String,
    val logo: String? = null,
    val group: String = "عام"
)

/** قنوات مجانية رسمية للتجربة. غيّرها أو أضف رابط M3U من الإعدادات. */
object SampleChannels {
    val list = listOf(
        Channel("DW English", "https://dwamdstream102.akamaized.net/hls/live/2015525/dwstream102/index.m3u8", null, "أخبار"),
        Channel("France 24 English", "https://static.france24.com/live/F24_EN_HI_HLS/live_web.m3u8", null, "أخبار"),
        Channel("Al Jazeera English", "https://live-hls-web-aje.getaj.net/AJE/index.m3u8", null, "أخبار"),
        Channel("NASA TV", "https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8", null, "علوم")
    )
}
