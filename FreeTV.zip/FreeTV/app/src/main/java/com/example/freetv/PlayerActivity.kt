package com.example.freetv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class PlayerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("url")
        if (url == null) { finish(); return }
        val name = intent.getStringExtra("name") ?: ""
        val saver = getSharedPreferences("prefs", 0).getBoolean("saver", true)
        setContent { AppTheme { PlayerScreen(name, url, saver, this) { finish() } } }
    }
}
