package com.example.freetv

import java.net.HttpURLConnection
import java.net.URL

object M3uParser {
    private val attr = Regex("([\\w-]+)=\"([^\"]*)\"")

    fun download(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    fun parse(text: String): List<Channel> {
        val out = mutableListOf<Channel>()
        var name = ""; var logo: String? = null; var group = "عام"
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF") -> {
                    val a = attr.findAll(line).associate { it.groupValues[1] to it.groupValues[2] }
                    logo = a["tvg-logo"]?.ifBlank { null }
                    group = a["group-title"]?.ifBlank { null } ?: "عام"
                    name = line.substringAfterLast(",").trim()
                }
                line.isNotEmpty() && !line.startsWith("#") -> {
                    if (name.isNotEmpty()) out += Channel(name, line, logo, group)
                    name = ""; logo = null; group = "عام"
                }
            }
        }
        return out
    }
}
