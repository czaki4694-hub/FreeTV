package com.example.freetv

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("prefs", 0)

    var channels by mutableStateOf(listOf<Channel>()); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var query by mutableStateOf("")
    var group by mutableStateOf<String?>(null)
    var current by mutableStateOf<Channel?>(null)
    var playlistUrl by mutableStateOf(prefs.getString("url", "") ?: "")
    var favorites by mutableStateOf(prefs.getStringSet("fav", emptySet())!!.toSet()); private set

    val groups: List<String>
        get() = listOf("المفضلة") + channels.map { it.group }.distinct().sorted()

    val filtered: List<Channel>
        get() = channels.filter {
            (group == null || (group == "المفضلة" && it.url in favorites) || it.group == group) &&
                it.name.contains(query, ignoreCase = true)
        }

    init { load() }

    fun savePlaylist(url: String) {
        playlistUrl = url.trim()
        prefs.edit().putString("url", playlistUrl).apply()
        load()
    }

    fun toggleFav(c: Channel) {
        favorites = if (c.url in favorites) favorites - c.url else favorites + c.url
        prefs.edit().putStringSet("fav", favorites).apply()
    }

    fun load() {
        viewModelScope.launch {
            loading = true; error = null
            try {
                channels = if (playlistUrl.isBlank()) SampleChannels.list
                else withContext(Dispatchers.IO) { M3uParser.parse(M3uParser.download(playlistUrl)) }
                group = null
            } catch (e: Exception) {
                error = "تعذّر تحميل القائمة"
                channels = SampleChannels.list
            }
            loading = false
        }
    }
}
