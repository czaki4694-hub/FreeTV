package com.example.freetv

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

// الاسم، أقصى ارتفاع (0 = تلقائي بلا حد)
private val levels = listOf("تلقائي" to 0, "ضعيفة" to 360, "متوسطة" to 480, "جيدة" to 720)

@Composable
fun PlayerScreen(name: String, url: String, saver: Boolean, activity: Activity, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build() }
    var sel by remember { mutableStateOf(if (saver) 2 else 0) }
    var showQuality by remember { mutableStateOf(false) }
    val land = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    fun apply(i: Int) {
        val h = levels[i].second
        val w = if (h == 0) Int.MAX_VALUE else h * 16 / 9
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setMaxVideoSize(w, if (h == 0) Int.MAX_VALUE else h).build()
    }

    LaunchedEffect(url) {
        apply(sel)
        player.setMediaItem(MediaItem.fromUri(url))
        player.prepare()
        player.playWhenReady = true
    }
    DisposableEffect(player) { onDispose { player.release() } }

    // إخفاء أشرطة النظام في الوضع الأفقي
    LaunchedEffect(land) {
        val c = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        if (land) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else c.show(WindowInsetsCompat.Type.systemBars())
    }

    BackHandler(onBack = onClose)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { PlayerView(it).apply { this.player = player; keepScreenOn = true } },
            modifier = Modifier.fillMaxSize()
        )
        Row(
            Modifier.fillMaxWidth().background(Color.Black.copy(alpha = 0.45f)).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "رجوع", tint = Color.White) }
            Text(name, color = Color.White, maxLines = 1, modifier = Modifier.weight(1f))
            // زر تدوير الشاشة
            TextButton(onClick = {
                activity.requestedOrientation =
                    if (land) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }) { Text("⟳ تدوير", color = Color.White) }
            TextButton(onClick = { showQuality = true }) { Text(levels[sel].first, color = Color.White) }
            // فتح في مشغّل خارجي (VLC, MX Player...)
            TextButton(onClick = {
                try {
                    ctx.startActivity(Intent.createChooser(
                        Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), "video/*"), "افتح بواسطة"))
                } catch (e: Exception) {
                    Toast.makeText(ctx, "لا يوجد مشغّل خارجي مثبّت", Toast.LENGTH_SHORT).show()
                }
            }) { Text("↗", color = Color.White) }
        }
    }

    if (showQuality) {
        AlertDialog(
            onDismissRequest = { showQuality = false },
            confirmButton = {},
            title = { Text("الجودة") },
            text = {
                Column {
                    levels.forEachIndexed { i, (label, h) ->
                        val text = if (h == 0) label else "$label (${h}p)"
                        Text(
                            text,
                            color = if (i == sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.fillMaxWidth()
                                .clickable { sel = i; apply(i); showQuality = false }
                                .padding(vertical = 12.dp)
                        )
                    }
                }
            }
        )
    }
}
