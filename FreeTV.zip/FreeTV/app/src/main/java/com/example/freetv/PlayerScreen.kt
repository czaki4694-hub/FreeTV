package com.example.freetv

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private data class Quality(val group: Tracks.Group, val index: Int, val height: Int)

@Composable
fun PlayerScreen(channel: Channel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build() }
    var qualities by remember { mutableStateOf(listOf<Quality>()) }
    var showQuality by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Int?>(null) } // null = تلقائي

    LaunchedEffect(channel.url) {
        player.setMediaItem(MediaItem.fromUri(channel.url))
        player.prepare()
        player.playWhenReady = true
    }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) {
                qualities = tracks.groups.filter { it.type == C.TRACK_TYPE_VIDEO }
                    .flatMap { g ->
                        (0 until g.length).filter { g.isTrackSupported(it) }
                            .map { Quality(g, it, g.getTrackFormat(it).height) }
                    }
                    .filter { it.height > 0 }
                    .distinctBy { it.height }
                    .sortedByDescending { it.height }
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }

    BackHandler(onBack = onClose)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { PlayerView(it).apply { this.player = player; keepScreenOn = true } },
            modifier = Modifier.fillMaxSize()
        )
        Row(
            Modifier.fillMaxWidth().background(Color.Black.copy(alpha = 0.45f)).padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "رجوع", tint = Color.White) }
            Text(channel.name, color = Color.White, modifier = Modifier.weight(1f))
            TextButton(onClick = { showQuality = true }) {
                Text(selected?.let { "${it}p" } ?: "تلقائي", color = Color.White)
            }
        }
    }

    if (showQuality) {
        AlertDialog(
            onDismissRequest = { showQuality = false },
            confirmButton = {},
            title = { Text("الجودة") },
            text = {
                Column {
                    QualityRow("تلقائي", selected == null) {
                        player.trackSelectionParameters = player.trackSelectionParameters
                            .buildUpon().clearOverridesOfType(C.TRACK_TYPE_VIDEO).build()
                        selected = null; showQuality = false
                    }
                    qualities.forEach { q ->
                        QualityRow("${q.height}p", selected == q.height) {
                            player.trackSelectionParameters = player.trackSelectionParameters
                                .buildUpon()
                                .setOverrideForType(TrackSelectionOverride(q.group.mediaTrackGroup, q.index))
                                .build()
                            selected = q.height; showQuality = false
                        }
                    }
                }
            }
        )
    }
}

@Composable
private fun QualityRow(label: String, active: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp)
    )
}
