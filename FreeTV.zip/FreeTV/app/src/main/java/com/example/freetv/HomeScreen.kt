@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.freetv

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

private val CardWhite = Color(0xFFF7F8FB)
private val Ink = Color(0xFF3A3F4B)

@Composable
fun HomeScreen(vm: MainViewModel) {
    var showSettings by remember { mutableStateOf(false) }
    val showChannels = vm.group != null || vm.query.isNotBlank()
    BackHandler(enabled = vm.group != null) { vm.group = null; vm.query = "" }

    Column(
        Modifier.fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 12.dp)
    ) {
        Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (vm.group != null)
                IconButton(onClick = { vm.group = null; vm.query = "" }) { Icon(Icons.Default.ArrowBack, "رجوع") }
            Text(vm.group ?: "القنوات", style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 4.dp))
            IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "الإعدادات") }
        }
        OutlinedTextField(
            value = vm.query, onValueChange = { vm.query = it },
            placeholder = { Text("ابحث عن قناة") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true, shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        when {
            vm.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            !showChannels -> LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(vm.groups) { g ->
                    val list = if (g == "المفضلة") vm.channels.filter { it.url in vm.favorites }
                    else vm.channels.filter { it.group == g }
                    TileCard(
                        logo = list.firstOrNull { it.logo != null }?.logo,
                        fallback = g.take(1),
                        label = g,
                        sub = "${list.size} قناة",
                        onClick = { vm.group = g }
                    )
                }
            }
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(vm.filtered, key = { it.url }) { ch ->
                    TileCard(
                        logo = ch.logo, fallback = ch.name.take(2).uppercase(), label = ch.name,
                        sub = null, fav = ch.url in vm.favorites,
                        onFav = { vm.toggleFav(ch) }, onClick = { vm.current = ch }
                    )
                }
            }
        }
    }

    if (showSettings) {
        var url by remember { mutableStateOf(vm.playlistUrl) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("قائمة القنوات") },
            text = {
                OutlinedTextField(url, { url = it }, label = { Text("رابط M3U") },
                    placeholder = { Text("اتركه فارغاً للقنوات التجريبية") })
            },
            confirmButton = { TextButton(onClick = { vm.savePlaylist(url); showSettings = false }) { Text("حفظ") } },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun TileCard(
    logo: String?, fallback: String, label: String, sub: String?,
    fav: Boolean? = null, onFav: (() -> Unit)? = null, onClick: () -> Unit
) {
    Card(
        onClick = onClick, shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite)
    ) {
        Column(Modifier.fillMaxWidth().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth().height(84.dp), contentAlignment = Alignment.Center) {
                if (logo != null)
                    AsyncImage(logo, label, contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize().padding(8.dp))
                else
                    Text(fallback, style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.9f), fontWeight = FontWeight.Bold)
                if (fav != null && onFav != null)
                    IconButton(onClick = onFav, modifier = Modifier.align(Alignment.TopEnd).size(32.dp)) {
                        Icon(Icons.Default.Favorite, "مفضلة",
                            tint = if (fav) Color(0xFFFF5C7A) else Color.Black.copy(alpha = 0.15f))
                    }
            }
            Text(label, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center, fontWeight = FontWeight.Medium)
            sub?.let { Text(it, color = Ink.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall) }
        }
    }
}
