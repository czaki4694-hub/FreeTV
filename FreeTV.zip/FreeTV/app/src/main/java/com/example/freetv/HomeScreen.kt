@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.freetv

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

@Composable
fun HomeScreen(vm: MainViewModel) {
    var showSettings by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp)
    ) {
        Row(Modifier.padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("القنوات", style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "الإعدادات") }
        }
        OutlinedTextField(
            value = vm.query, onValueChange = { vm.query = it },
            placeholder = { Text("ابحث عن قناة") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true, shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.groups) { g ->
                FilterChip(selected = vm.group == g, onClick = { vm.group = g }, label = { Text(g) })
            }
        }
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }

        if (vm.loading) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(150.dp),
                contentPadding = PaddingValues(vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(vm.filtered, key = { it.url }) { ch ->
                    ChannelCard(ch, ch.url in vm.favorites,
                        onClick = { vm.current = ch }, onFav = { vm.toggleFav(ch) })
                }
            }
        }
    }

    if (showSettings) {
        var url by remember { mutableStateOf(vm.playlistUrl) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("قائمة القنوات") },
            text = {
                OutlinedTextField(url, { url = it }, label = { Text("رابط M3U") },
                    placeholder = { Text("اتركه فارغاً للقنوات التجريبية") })
            },
            confirmButton = { TextButton(onClick = { vm.savePlaylist(url); showSettings = false }) { Text("حفظ") } },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun ChannelCard(ch: Channel, fav: Boolean, onClick: () -> Unit, onFav: () -> Unit) {
    Card(
        onClick = onClick, shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            Box(
                Modifier.fillMaxWidth().height(90.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (ch.logo != null)
                    AsyncImage(ch.logo, ch.name, contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize().padding(16.dp))
                else
                    Text(ch.name.take(2).uppercase(), style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                IconButton(onClick = onFav, modifier = Modifier.align(Alignment.TopEnd)) {
                    Icon(Icons.Default.Favorite, "مفضلة",
                        tint = if (fav) Color(0xFFFF5C7A) else Color.White.copy(alpha = 0.25f))
                }
            }
            Text(ch.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.Medium, modifier = Modifier.padding(12.dp))
        }
    }
}
