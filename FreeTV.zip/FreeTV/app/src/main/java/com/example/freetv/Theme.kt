package com.example.freetv

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Colors = darkColorScheme(
    primary = Color(0xFF7C9CFF),
    onPrimary = Color(0xFF0B1020),
    background = Color(0xFF0E1016),
    surface = Color(0xFF181B25),
    surfaceVariant = Color(0xFF222633),
    onBackground = Color(0xFFEDEFF5),
    onSurface = Color(0xFFEDEFF5)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = Colors, content = content)
